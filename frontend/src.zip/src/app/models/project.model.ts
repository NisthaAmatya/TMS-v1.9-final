export class ProjSpace {
_id: string;
_workspaceId: string;
_Proj_Name: string;
_Proj_Desc: string;
_Start_Date: Date;
_End_Date: Date

}

export class TaskSpace {
  _id: string;
  _workspaceId: string;
  _projectId: string;
  Task_Name : string;
  Task_Desc : string;
  Start_Date : Date;
  End_Date : Date;
  Priority : string;
  Attach_File : string;
  Comments : string;
  EmpName: string;
  Status  : string;

}

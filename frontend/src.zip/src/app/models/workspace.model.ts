export class WorkSpace {
  _id: string;
  _Work_Name: string;
  _Work_Desc: string
}

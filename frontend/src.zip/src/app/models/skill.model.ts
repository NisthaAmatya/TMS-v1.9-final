export class SkillSpace {
  _id: string;
  _Skill_Desc: string;
  _Skill_Name: string;

}

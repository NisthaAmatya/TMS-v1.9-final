export class EmployeeSpace {
  _id: string;
  _Emp_Name: string;
  _Emp_Addr: string;
  _Emp_Phone: string;
  _Emp_Email: string;
  _Skill_Name_1: string;
  _Skill_Name_2: string;
  _Skill_Name_3: string;
  _Leave_StartDate: Date;
  _Leave_EndDate: Date;

}
